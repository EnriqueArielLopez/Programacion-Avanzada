package Codominio;

import javax.swing.JOptionPane;

import Dominio.personaInterface;

public class Persona implements personaInterface{
	private String usuario;
	private String clave;
	private double saldo;
	private boolean alta;
	
	public Persona(String usuario,String clave,double saldo,boolean alta) {
		
		this.usuario=usuario;
		this.clave= clave;
		this.saldo=saldo;
		this.alta= alta;
		
	}


	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public String getUsuario() {
		return usuario;
	}
	
	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}
	
	public boolean getAlta() {
		return alta;
	}
	
	public void setAlta(boolean alta) {
		this.alta=alta;
	}

	
	@Override
	public void ingresar(Persona persona) {
		
		String user = JOptionPane.showInputDialog("Ingresar usario");
		String clave = JOptionPane.showInputDialog("Ingresar clave");
		
		if(user.equals(persona.getUsuario()) && clave.equalsIgnoreCase(persona.getClave())) {
			
			persona.setAlta(true);
			
			System.out.println("Ingresaste correctamente");
			
		}
		
		else {
			System.out.println("Usuario o clave incorrecta");
		}

		
	}
	
	
	@Override
	public void consultarSaldo(Banco banco, Cajero cajero, Persona persona) {
		
				if(cajero.getEstado()==true && persona.alta==true) {
					
					System.out.println("Su saldo actual es de: "+persona.getSaldo());				
					
				}
				else {
					System.out.println("No se puede realizar la operacion");
				}
		
	}
	
	@Override
	public void extraerDinero(Banco banco, Cajero cajero, Persona persona, double montoAExtraer) {

		if(persona.getAlta()==true) {
			
	
					if(cajero.getEstado()==true && cajero.getCantidadDinero()>=0 && cajero.getCantidadDinero()>montoAExtraer) {
							
									if(persona.getSaldo()>montoAExtraer) {
										persona.setSaldo(getSaldo()+montoAExtraer);
										System.out.println(montoAExtraer +" Fueron extraidos de su cuenta");
				
									}
									
									else {
										System.out.println("El monto a extraer es superior a su saldo actual");
						
									}
							
					}
	
					else {
							System.out.println("Esta operacion no se puede realizar");
					}
				
		}
		
		else {
			System.out.println("Usuario o clave incorrecto");
		}
		
	}

	@Override
	public void realizarTransferencia(Banco banco, Cajero cajero, personaInterface persona,
			personaInterface personaExterna, double montoATransferir) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cambiarClave(Persona persona) {
		
		if(persona.getAlta()==true) {
				String verificarClave =  JOptionPane.showInputDialog("Ingresar clave actual");
				
				if(verificarClave.equalsIgnoreCase(persona.getClave())) {
						String nuevaClaveUser = JOptionPane.showInputDialog("Ingresar nueva clave");
						persona.setClave(nuevaClaveUser);
						System.out.println("Clave modificada con exito");
					
				}
				else {
					System.out.println("La clave es incorrecta");
				}
				
		}
			
	}



	

}
