package Codominio;

import Dominio.bancoInterface;

public class Banco implements bancoInterface{
	
	private String nombreBanco;
	private int idSucursal;
	private double capitalBanco;
	
	public Banco (String nombreBanco,int idSucursal,double capitalBanco) {
		
		this.nombreBanco=nombreBanco;
		this.idSucursal=idSucursal;
		this.capitalBanco=capitalBanco;
		
	}

	@Override
	public void ingresarDinero(Cajero cajero,int cantidadDinero) {

			if(cantidadDinero<=0) {
				System.out.println("No se puede ingresar dinero con monto menor o igual a 0");
			}
			
			else {
				
				cajero.setCantidadDinero(cajero.getCantidadDinero()+cantidadDinero);
				
				System.out.println("Saldo actual del cajero: "+cajero.getCantidadDinero());
				
			}
			
	}
	
	
}
