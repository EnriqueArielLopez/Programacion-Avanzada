package Codominio;
import Dominio.cajeroInterface;

public class Cajero implements cajeroInterface{
	
	private boolean estado;
	private int id;
	private int cantidadDinero;
	private String nombreBanco;
	
	public Cajero(boolean estado, int id, int cantidadDinero, String nombreBanco){
		
		this.estado=estado;
		this.id=id;
		this.cantidadDinero= cantidadDinero;
		this.nombreBanco=nombreBanco;
		
	}
	

	public boolean getEstado() {
		return estado;
	}



	public void setEstado(boolean estado) {
		this.estado = estado;
	}



	public int getCantidadDinero() {
		return cantidadDinero;
	}



	public void setCantidadDinero(int cantidadDinero) {
		this.cantidadDinero = cantidadDinero;
	}


	public String getNombreBanco() {
		return nombreBanco;
	}



	public void setNombreBanco(String nombreBanco) {
		this.nombreBanco = nombreBanco;
	}



	public int getId() {
		return id;
	}


	@Override
	public void encender(Cajero cajero) {
		if(cajero.getEstado()==false) {
			System.out.println("Cajero encendido....");
			cajero.setEstado(true);
		}
		else {
			System.out.println("El cajero ya esta encendido");
		}
		
	}

	@Override
	public void apagar(Cajero cajero) {
		if(cajero.getEstado()==true) {
			System.out.println("Cajero apagado....");
			cajero.setEstado(false);
		}
		else {
			System.out.println("El cajero ya esta apagado");
		}		
	}


	@Override
	public void saldoCajero(Cajero cajero) {
			if(cajero.getEstado()==true) {
					if(cajero.getCantidadDinero()<=0) {
						System.out.println("Cajero sin efectivo");
					}
					
					else {
						System.out.println("Saldo actual del cajero: "+cajero.getCantidadDinero());
					}		
			}
			else {
				System.out.println("Error estado del cajero "+cajero.getEstado());
			}
	
	}




}
