import Codominio.Banco;
import Codominio.Cajero;
import Codominio.Persona;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Banco Banelco = new Banco ("Banelco",1,99999);
		Cajero cajero1 = new Cajero(false,1,1,"Banelco");
		Persona Juan = new Persona("Juan","1234",10000,false);
		cajero1.apagar(cajero1);
		cajero1.saldoCajero(cajero1);
		cajero1.encender(cajero1);
		cajero1.saldoCajero(cajero1);
		cajero1.encender(cajero1);
		Banelco.ingresarDinero(cajero1, 10000);
		
		/*Juan.consultarSaldo(Banelco, cajero1, Juan);
		Juan.extraerDinero(Banelco, cajero1, Juan, 100);*/
		
		/*Metodos del usuario */
		Juan.ingresar(Juan);
		Juan.cambiarClave(Juan);
		Juan.cambiarClave(Juan);

		
	}

}
