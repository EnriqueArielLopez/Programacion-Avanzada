package Dominio;

import Codominio.Cajero;

public interface bancoInterface {

	
	public void ingresarDinero(Cajero cajero,int cantidadDinero);

}
