package Dominio;

import Codominio.Cajero;

public interface cajeroInterface {

	public void encender(Cajero cajero);
	public void apagar(Cajero cajero);
	public void saldoCajero(Cajero cajero);
	
}
