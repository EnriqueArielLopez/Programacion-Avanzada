package Dominio;

import Codominio.Banco;
import Codominio.Cajero;
import Codominio.Persona;

public interface personaInterface {
	
	public void ingresar (Persona persona);
	public void extraerDinero(Banco banco, Cajero cajero,Persona persona,double montoAExtraer);
	public void consultarSaldo(Banco banco,Cajero cajero,Persona persona);
	public void realizarTransferencia(Banco banco,Cajero cajero,personaInterface persona,personaInterface personaExterna,double montoATransferir);
	public void cambiarClave(Persona persona);

}
